# main.py
# 🌿 Cassino Bombardeiro — Versão Natureza (JSON, empréstimos com botões, admin)
# IMPORTANTE: substitua TOKEN e CHAT_ID antes de rodar.

import json
import os
import random
import time
import datetime
import asyncio
import uuid
from typing import Dict, Any
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, CallbackQueryHandler

# ---------------- CONFIG ----------------
TOKEN = os.getenv("TOKEN")
if not TOKEN:
    raise RuntimeError("Defina a variável de ambiente TOKEN no Railway com o token do BotFather.")
ADMINS = [6472213397]  # seu ID de admin (substitua)
CHAT_ID = -1002825062780  # ex: -1001234567890 (substitua)

DADOS_PATH = "dados.json"
DROPS_PATH = "drops.json"
DIVIDAS_PATH = "dividas.json"
# --- TEMA NATUREZA ---
EVENT_NAME = "🌿 Floresta Bombardeira"
EVENT_EMOJI = "🌿🍃🌳🦋"
# Tema fixo de natureza.
# Mantido event_active() retornando False para preservar compatibilidade interna sem bônus sazonais.
# ------------------------------

TAXA_PERCENTUAL = 3        # taxa sobre ganhos (vai pro cofre do cassino)
EMP_CASINO_INTEREST = 10   # juros fixos do cassino (10%)
LOAN_DEFAULT_DAYS = 1
LOAN_MAX_DAYS = 30         # limite máximo de dias para empréstimos entre jogadores

# runtime
cooldowns: Dict[str, float] = {}
# Controla o drop automático por hora
hourly_drop_status = {"last_hour": -1}

# LOJA TEMA NATUREZA
LOJA_ITENS = {
    "semente": {
        "nome": "🌱 Semente da Sorte",
        "preco": 35000,
        "descricao": "Use para ganhar coins aleatórios entre 1.000 e 12.000."
    },
    "trevo": {
        "nome": "🍀 Trevo Encantado",
        "preco": 120000,
        "descricao": "Aumenta em 20% a chance de vitória na próxima partida."
    },
    "mel": {
        "nome": "🍯 Mel Dourado",
        "preco": 200000,
        "descricao": "Dobra o prêmio bruto da próxima vitória."
    },
    "vassoura": {
        "nome": "🪶 Asa de Beija-flor",
        "preco": 250000,
        "descricao": "Reduz pela metade o cooldown do cassino e do bônus por 24 horas."
    },
    "vipfloresta": {
        "nome": "👑 Guardião da Floresta",
        "preco": 40000000,
        "descricao": "Bônus diário dobrado permanentemente."
    },
    "baudeouro": {
        "nome": "🪵 Baú da Clareira",
        "preco": 450000,
        "descricao": "Use para abrir um baú com prêmio entre 25.000 e 150.000 coins."
    },
    "escudo": {
        "nome": "🛡️ Casca Protetora",
        "preco": 300000,
        "descricao": "Protege 50% da sua próxima perda no cassino."
    },
    "mapa": {
        "nome": "🗺️ Mapa da Trilha",
        "preco": 150000,
        "descricao": "Use no /explorar para aumentar as recompensas da expedição."
    },
}

# Apelidos antigos e novos para não quebrar inventários/compras anteriores.
ITEM_ALIASES = {
    "foguete": "semente",
    "caixa": "semente",
    "semente": "semente",
    "trevo": "trevo",
    "renasorte": "trevo",
    "champanhe": "mel",
    "chapeu": "mel",
    "mel": "mel",
    "vassoura": "vassoura",
    "vipano": "vipfloresta",
    "vip": "vipfloresta",
    "vipfloresta": "vipfloresta",
    "baudeouro": "baudeouro",
    "bau": "baudeouro",
    "escudo": "escudo",
    "mapa": "mapa",
}


# ---------------- I/O helpers ----------------
def carregar_json(path: str, default):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except:
                return default
    return default

def salvar_json(path: str, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def carregar_dados():
    default = {
        "users": {},
        "user_id_counter": 0,
        "banco_cassino": 0,
        "global_effects": {},
        "stats": {"total_vitorias": 0, "total_derrotas": 0}
    }
    return carregar_json(DADOS_PATH, default)

def salvar_dados(obj):
    salvar_json(DADOS_PATH, obj)

def carregar_drops():
    return carregar_json(DROPS_PATH, {})

def salvar_drops(obj):
    salvar_json(DROPS_PATH, obj)

def carregar_dividas():
    default = {"next_id": 1, "loans": {}}
    return carregar_json(DIVIDAS_PATH, default)

def salvar_dividas(obj):
    salvar_json(DIVIDAS_PATH, obj)

# ---------------- carregar arquivos ----------------
dados = carregar_dados()
drops = carregar_drops()
dividas = carregar_dividas()

# ---------------- util ----------------
def agora_ts() -> int:
    return int(time.time())

def formatar(valor) -> str:
    try:
        return f"{int(valor):,}".replace(",", ".")
    except:
        return str(valor)

def event_active(now=None) -> bool:
    return False

def init_user(uid):
    uid = str(uid)
    if uid not in dados["users"]:
        dados["user_id_counter"] = dados.get("user_id_counter", 0) + 1
        dados["users"][uid] = {
            "saldo": 1000,
            "ultimo_bonus": 0,
            "ultimo_juros_coletado": 0,
            "game_id": f"{dados['user_id_counter']:02d}",
            "itens": {},
            "efeitos": {},
            "boost_jogos": 0,
            "stats": {"vitorias": 0, "derrotas": 0}
        }
        salvar_dados(dados)
    else:
        if "stats" not in dados["users"][uid]:
            dados["users"][uid]["stats"] = {"vitorias": 0, "derrotas": 0}
            salvar_dados(dados)

def aplicar_taxa(valor):
    taxa = int(valor * TAXA_PERCENTUAL / 100)
    dados["banco_cassino"] = dados.get("banco_cassino", 0) + taxa
    salvar_dados(dados)
    return taxa, valor - taxa

def gerar_loan_id_sequencial():
    nid = dividas.get("next_id", 1)
    dividas["next_id"] = nid + 1
    salvar_dividas(dividas)
    return str(nid)

def contar_jogadores():
    return len(dados.get("users", {}))

# ---------------- comandos básicos ----------------
async def iniciar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    init_user(uid)
    titulo = f"🌿 Cassino Bombardeiro — {EVENT_NAME} {EVENT_EMOJI}"
    await update.message.reply_text(
        f"{titulo}\n\n🎁 Bem-vindo(a) à Floresta Bombardeira!\n"
        "Você recebeu 1.000 coins para começar.\n"
        "Use /ajuda para ver os comandos e /loja para conhecer os itens da natureza."
    )

async def saldo_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    init_user(uid)
    await update.message.reply_text(f"👤 ID: {dados['users'][uid]['game_id']}\n💰 Saldo: {formatar(dados['users'][uid]['saldo'])} coins")

# ---------------- bônus diário ----------------
async def bonus_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id); init_user(uid)
    agora = agora_ts()
    # cooldown e efeitos (usando 'pocao' e 'vassoura_end' como no script original)
    cooldown = 43200 if dados["users"][uid]["itens"].get("pocao", False) else 86400
    vass_end = dados["users"][uid].get("efeitos", {}).get("vassoura_end", 0)
    if vass_end and int(vass_end) > agora:
        cooldown = cooldown // 2
    if agora - dados["users"][uid]["ultimo_bonus"] < cooldown:
        restante = int(cooldown - (agora - dados["users"][uid]["ultimo_bonus"]))
        h = restante // 3600; m = (restante % 3600)//60
        return await update.message.reply_text(f"⏳ Volte em {h}h {m}m para pegar outro bônus.")
    
    premio = random.randint(100, 1000)
    
    # VIP antigo e novo dobram o bônus diário.
    itens_user = dados["users"][uid].setdefault("itens", {})
    if itens_user.get("vip", 0) or itens_user.get("vipfloresta", 0):
        premio *= 2
        
    dados["users"][uid]["saldo"] += premio
    dados["users"][uid]["ultimo_bonus"] = agora
    salvar_dados(dados)
    
    await update.message.reply_text(
        f"🌿 BÔNUS DA FLORESTA {EVENT_EMOJI}\n"
        f"Você recebeu: {formatar(premio)} coins!"
    )

# ---------------- loja ----------------
async def loja_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    titulo = f"🌿🛍️ Loja da Floresta Bombardeira {EVENT_EMOJI}"
    texto = f"{titulo}\n\n"
    for key, info in LOJA_ITENS.items():
        texto += f"/{key} - {info['nome']}\n   💰 {formatar(info['preco'])} coins\n   📄 {info['descricao']}\n\n"
    texto += "Use /comprar <item> para adquirir e /usar <item> para usar (quando aplicável)."
    await update.message.reply_text(texto)

async def comprar_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id); init_user(uid)
    if len(context.args) != 1:
        return await update.message.reply_text("Use: /comprar <nome_do_item>")
    item = context.args[0].lower()
    
    canonical = ITEM_ALIASES.get(item, item)

    if canonical not in LOJA_ITENS:
        return await update.message.reply_text("❌ Item não encontrado.")
        
    info = LOJA_ITENS[canonical]
    preco = info["preco"]
    
    if dados["users"][uid]["saldo"] < preco:
        return await update.message.reply_text("❗ Saldo insuficiente.")
        
    dados["users"][uid]["saldo"] -= preco
    itens = dados["users"][uid].setdefault("itens", {})
    
    itens[canonical] = itens.get(canonical, 0) + 1
    
    salvar_dados(dados)
    await update.message.reply_text(f"✅ Você comprou '{info['nome']}' por {formatar(preco)} coins.")

# ---------------- cassino (jogo) ----------------
def calcular_multiplicador():
    r = random.randint(1, 100)
    if r <= 5:
        return 10
    elif r <= 25:
        return 5
    elif r <= 65:
        return 4
    else:
        return 2

async def cassino_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    uid = str(user.id)
    init_user(uid)

    if len(context.args) != 1:
        return await update.message.reply_text("Use: /cassino <valor|all>")

    arg = context.args[0].lower()
    try:
        saldo = dados["users"][uid]["saldo"]
        valor = saldo if arg == "all" else float(arg.replace(",", "."))
    except:
        return await update.message.reply_text("❗ Valor inválido.")
    if valor <= 0 or saldo < valor:
        return await update.message.reply_text("❗ Saldo insuficiente.")

    agora = agora_ts()
    cooldown_base = 5
    vass_end = dados["users"][uid].get("efeitos", {}).get("vassoura_end", 0)
    if vass_end and int(vass_end) > agora:
        cooldown_base = max(1, cooldown_base // 2)
    if uid in cooldowns and agora - cooldowns[uid] < cooldown_base:
        return await update.message.reply_text(f"⏳ Aguarde {cooldown_base} segundos entre apostas.")
    cooldowns[uid] = agora

    msg = await update.message.reply_text("🎰 Girando a roleta...")
    await asyncio.sleep(2)

    # chance fixa de vitória: 45%
    roll = random.random()
    # O trevo aumenta a chance da próxima partida.
    itens_user = dados["users"][uid].setdefault("itens", {})
    trevos = itens_user.get("trevo", 0) + itens_user.get("renasorte", 0)
    if trevos > 0:
        roll -= 0.20
        if itens_user.get("trevo", 0) > 0:
            itens_user["trevo"] -= 1
        else:
            itens_user["renasorte"] -= 1
        
    if roll < 0.45:
        multiplicador = calcular_multiplicador()
    else:
        multiplicador = 0

    ganho_bruto = round(valor * multiplicador)

    if multiplicador == 0:
        itens_user = dados["users"][uid].setdefault("itens", {})
        perda = valor
        if itens_user.get("escudo", 0) > 0:
            perda = valor * 0.5
            itens_user["escudo"] -= 1
        dados["users"][uid]["saldo"] -= perda
        dados["users"][uid]["stats"]["derrotas"] = dados["users"][uid]["stats"].get("derrotas", 0) + 1
        dados["stats"]["total_derrotas"] = dados["stats"].get("total_derrotas", 0) + 1
        resultado = f"Você perdeu {formatar(perda)} coins."
    else:
        # aplica efeitos que alteram ganho
        pocao_flag = dados["users"][uid].get("efeitos", {}).get("pocao_next", False)
        if pocao_flag:
            ganho_bruto *= 2
            dados["users"][uid]["efeitos"].pop("pocao_next", None)
        taxa, ganho_liquido = aplicar_taxa(ganho_bruto)
        dados["users"][uid]["saldo"] += ganho_liquido
        dados["users"][uid]["stats"]["vitorias"] = dados["users"][uid]["stats"].get("vitorias", 0) + 1
        dados["stats"]["total_vitorias"] = dados["stats"].get("total_vitorias", 0) + 1
        resultado = (
            f"VITÓRIA! Você ganhou +{formatar(ganho_liquido)} coins!\n\n"
            f"Aposta: {formatar(valor)} coins\n"
            f"Multiplicador: x{multiplicador}\n"
            f"Taxa do cassino ({TAXA_PERCENTUAL}%): {formatar(taxa)} coins"
        )

    salvar_dados(dados)
    await msg.edit_text(f"🎰 @{user.username or user.first_name} girou a roleta!\n\n{resultado}")

# ---------------- rank / doar / addsaldo / drop ----------------
# A função drop_cmd é apenas para drops manuais de admin.
# A lógica de pegar o drop (callback) é a que faltava.

# FUNÇÃO QUE FALTAVA (pegar_drop_callback)
async def pegar_drop_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not query.data or not query.data.startswith("pegardrop_"):
        await query.answer("Drop inválido.", show_alert=True)
        return
    
    uid = str(query.from_user.id)
    drop_id = query.data.split("_")[1]
    
    if drop_id not in drops:
        await query.answer("❌ Este drop não existe mais ou expirou.", show_alert=True)
        return

    drop = drops[drop_id]
    
    if uid in drop["pegos"]:
        await query.answer("❌ Você já pegou este drop.", show_alert=True)
        return

    if drop["quantidade"] <= len(drop["pegos"]):
        # Tenta editar a mensagem para avisar que acabou
        try:
            await query.edit_message_reply_markup(reply_markup=None)
            await query.edit_message_text(query.message.text + "\n\n❌ **DROP ESGOTADO!**", parse_mode="Markdown")
            drops.pop(drop_id, None)
            salvar_drops(drops)
        except:
            pass
            
        await query.answer("❌ DROP ESGOTADO!", show_alert=True)
        return
    
    # Processa o resgate
    init_user(uid)
    dados["users"][uid]["saldo"] += drop["valor"]
    drop["pegos"].append(uid)
    salvar_dados(dados)
    salvar_drops(drops)
    
    # Verifica se esgotou após este resgate
    if drop["quantidade"] == len(drop["pegos"]):
        try:
            await query.edit_message_reply_markup(reply_markup=None)
            await query.edit_message_text(query.message.text + "\n\n✅ Drop resgatado por último!", parse_mode="Markdown")
            drops.pop(drop_id, None)
            salvar_drops(drops)
        except:
            pass 

        await query.answer(f"✅ Você resgatou {formatar(drop['valor'])} coins! DROP ESGOTADO.", show_alert=True)
        return
    
    # Resgate normal
    await query.answer(f"✅ Você resgatou {formatar(drop['valor'])} coins!", show_alert=True)

async def drop_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    if user.id not in ADMINS:
        await update.message.reply_text("❌ Apenas admins podem usar.", parse_mode="Markdown")
        return
    if len(context.args) != 2:
        await update.message.reply_text("Use: /drop <valor> <quantidade>", parse_mode="Markdown")
        return

    try:
        valor = float(context.args[0].replace(",", "."))
        quantidade = int(context.args[1])
    except:
        await update.message.reply_text("❗ Valores inválidos.", parse_mode="Markdown")
        return

    drop_id = str(uuid.uuid4())
    drops[drop_id] = {"valor": valor, "quantidade": quantidade, "pegos": []}
    salvar_drops(drops)

    kb = [[InlineKeyboardButton("🎁 Resgatar", callback_data=f"pegardrop_{drop_id}")]]

    await update.message.reply_text(
        f"🌿 Drop da Floresta {EVENT_EMOJI}\n\n"
        f"👤 Criado por: @{user.username or user.first_name}\n"
        f"💰 Valor: {formatar(valor)}\n"
        f"🎯 Quantidade: {quantidade}\n"
        f"🔮 Total: {formatar(valor * quantidade)}",
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="Markdown"
    )

# ---------------- outras funções básicas (manter) ----------------
# ... (rank, doar, addsaldo, cassino_saldo, coletartaxa, cassino_status, emprestar, etc.)
# ... (para economizar espaço, essas funções foram omitidas, mas estão no código final)

async def rank_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    top = sorted(dados["users"].items(), key=lambda x: x[1].get("saldo", 0), reverse=True)[:10]
    texto = "🏆 Ranking dos mais Ricos 🏆\n\n"
    medalhas = ["🥇","🥈","🥉"]
    for i, (uid, info) in enumerate(top, 1):
        try:
            user = await context.bot.get_chat(int(uid))
            nome = user.first_name or user.username or f"Usuário-{uid}"
        except:
            nome = f"Usuário-{uid}"
        medalha = medalhas[i-1] if i <= 3 else "🏅"
        texto += f"{medalha} {nome} - 💰 {formatar(info.get('saldo',0))} coins\n"
    await update.message.reply_text(texto)

async def doar_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) != 1 or not update.message.reply_to_message:
        return await update.message.reply_text("Use: /doar <valor> respondendo à mensagem de alguém.")
    remetente = str(update.effective_user.id)
    destinatario = str(update.message.reply_to_message.from_user.id)
    init_user(remetente); init_user(destinatario)
    try:
        valor = float(context.args[0].replace(",", "."))
    except:
        return await update.message.reply_text("❗ Valor inválido.")
    if valor <= 0 or dados["users"][remetente]["saldo"] < valor:
        return await update.message.reply_text("❗ Saldo insuficiente.")
    dados["users"][remetente]["saldo"] -= valor
    dados["users"][destinatario]["saldo"] += valor
    salvar_dados(dados)
    await update.message.reply_text(f"✅ Você doou {formatar(valor)} coins com sucesso.")

async def addsaldo_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMINS:
        return await update.message.reply_text("❌ Apenas admins podem usar esse comando.")
    # permite reply ou id + valor
    if update.message.reply_to_message:
        if len(context.args) != 1:
            return await update.message.reply_text("Use: /addsaldo <valor> respondendo a mensagem do usuário.")
        target = str(update.message.reply_to_message.from_user.id)
        try:
            valor = float(context.args[0].replace(",", "."))
        except:
            return await update.message.reply_text("❗ Valor inválido.")
    else:
        if len(context.args) != 2:
            return await update.message.reply_text("Use: /addsaldo <@usuário/id> <valor>")
        target = context.args[0]
        try:
            valor = float(context.args[1].replace(",", "."))
        except:
            return await update.message.reply_text("❗ Valor inválido.")
    init_user(target)
    dados["users"][target]["saldo"] += valor
    salvar_dados(dados)
    await update.message.reply_text(f"✅ {formatar(valor)} coins adicionados para {target}.")

async def cassino_saldo_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    banco = dados.get("banco_cassino", 0)
    titulo = "🏦 Cofre do Cassino Bombardeiro"
    await update.message.reply_text(f"{titulo}\n💰 Saldo atual: {formatar(banco)} coins\n📉 Taxa atual: {TAXA_PERCENTUAL}%")

async def coletartaxa_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMINS:
        return await update.message.reply_text("🚫 Apenas admins podem coletar as taxas!")
    banco = dados.get("banco_cassino",0)
    if banco <= 0:
        return await update.message.reply_text("🏦 Cofre vazio.")
    admin_id = str(update.effective_user.id); init_user(admin_id)
    dados["users"][admin_id]["saldo"] += banco
    dados["banco_cassino"] = 0
    salvar_dados(dados)
    await update.message.reply_text(f"💰 Você coletou {formatar(banco)} coins das taxas do Cassino Bombardeiro!")

async def cassino_status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMINS:
        return await update.message.reply_text("🚫 Apenas admins podem ver o status detalhado.")
    num_players = contar_jogadores()
    coins_total = (sum(u.get("saldo", 0) for u in dados.get("users", {}).values()) + 
                   dados.get("banco_cassino", 0))
    lucro = dados.get("banco_cassino", 0)
    loans = dividas.get("loans", {})
    active_loans = [l for k,l in loans.items() if isinstance(k,str) and k.isdigit() and l.get("status") == "active"]
    total_dividas = sum(l.get("amount",0) + l.get("amount",0)*(l.get("interest_pct",0)/100) for l in active_loans)
    texto = (
        f"📊 Status do Cassino Bombardeiro:\n\n"
        f"👥 Jogadores registrados: {num_players}\n"
        f"💰 Coins em circulação (usuários + cofre): {formatar(coins_total)}\n"
        f"🏦 Cofre (taxas): {formatar(dados.get('banco_cassino',0))}\n"
        f"📉 Lucro estimado: {formatar(lucro)}\n"
        f"💸 Dívidas ativas: {len(active_loans)} | Total aproximado a pagar: {formatar(total_dividas)}\n"
    )
    await update.message.reply_text(texto)

async def emprestar_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lender = update.effective_user
    lender_id = str(lender.id)
    init_user(lender_id)
    message = update.message
    if not message or not message.reply_to_message:
        return await message.reply_text("❗ Responda à mensagem da pessoa para quem deseja oferecer o empréstimo com: /emprestar <valor> <juros%?> <dias?>")
    if len(context.args) < 1:
        return await message.reply_text("Use: /emprestar <valor> <juros%?> <dias?> (responda à mensagem do destinatário).")
    try:
        valor = float(context.args[0].replace(",", "."))
    except:
        return await message.reply_text("❗ Valor inválido.")
    juros_pct = EMP_CASINO_INTEREST
    dias = LOAN_DEFAULT_DAYS
    if len(context.args) >= 2:
        try:
            juros_pct = float(context.args[1])
        except:
            juros_pct = EMP_CASINO_INTEREST
    if len(context.args) >= 3:
        try:
            dias = int(context.args[2])
        except:
            dias = LOAN_DEFAULT_DAYS
    if valor <= 0 or juros_pct < 0 or dias <= 0 or dias > LOAN_MAX_DAYS:
        return await message.reply_text("❗ Valores inválidos ou prazo excede o máximo permitido.")
    destinatario_user = message.reply_to_message.from_user
    destinatario_id = str(destinatario_user.id)
    if destinatario_id == lender_id:
        return await message.reply_text("❗ Você não pode emprestar para si mesmo.")
    if dados["users"][lender_id]["saldo"] < valor:
        return await message.reply_text("❗ Saldo insuficiente para oferecer esse empréstimo.")
    dados["users"][lender_id]["saldo"] -= valor
    salvar_dados(dados)
    loan_id = gerar_loan_id_sequencial()
    created = agora_ts()
    due = created + (dias * 24 * 3600)
    dividas.setdefault("loans", {})[loan_id] = {
        "id": loan_id,
        "from": lender_id,
        "to": destinatario_id,
        "amount": valor,
        "interest_pct": float(juros_pct),
        "created": created,
        "due": due,
        "status": "pending",
        "escrowed": True
    }
    salvar_dividas(dividas)
    lender_name = lender.username or lender.first_name
    texto = (
        f"🧾 *Proposta de Empréstimo*\n\n"
        f"De: @{lender_name}\n"
        f"Valor: {formatar(valor)} coins\n"
        f"Juros: {juros_pct}%\n"
        f"Prazo: {dias} dia(s)\n\n"
        f"ID da proposta: #{loan_id}\n\n"
        f"Aceitar ou recusar?"
    )
    kb = [[
        InlineKeyboardButton("✅ Aceitar", callback_data=f"loanresp|{loan_id}|accept"),
        InlineKeyboardButton("❌ Recusar", callback_data=f"loanresp|{loan_id}|decline"),
    ]]
    try:
        await message.reply_text(texto, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")
    except:
        await message.reply_text(texto)
    await message.reply_text(f"✅ Proposta criada (ID: #{loan_id}). Aguardando resposta do destinatário.")

async def loan_response_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not query.data: return
    parts = query.data.split("|")
    if len(parts) != 3 or parts[0] != "loanresp": return
    _, loan_id, action = parts
    loan = dividas.get("loans", {}).get(loan_id)
    if not loan: return await query.answer("❌ Essa proposta não existe ou expirou.", show_alert=True)
    user_click_id = str(query.from_user.id)
    if user_click_id != str(loan["to"]): return await query.answer("❌ Só o destinatário pode aceitar/recusar essa proposta.", show_alert=True)
    if loan["status"] != "pending": return await query.answer("⚠️ Esta proposta já foi tratada.", show_alert=True)
    lender_uid = str(loan["from"])
    amount = float(loan["amount"])
    if action == "accept":
        init_user(loan["to"])
        dados["users"][loan["to"]]["saldo"] += amount
        loan["status"] = "active"
        loan["activated"] = agora_ts()
        loan["escrowed"] = False
        salvar_dados(dados); salvar_dividas(dividas)
        await query.answer(f"✅ Empréstimo aceito! Você recebeu {formatar(amount)} coins.", show_alert=True)
        try: await context.bot.send_message(int(lender_uid), f"✅ Sua proposta #{loan_id} foi ACEITA por {loan['to']}.")
        except: pass
        try: await query.edit_message_text(f"✅ Empréstimo aceito! Você recebeu {formatar(amount)} coins. ID do empréstimo: #{loan_id}")
        except: pass
    else:
        init_user(lender_uid)
        dados["users"][lender_uid]["saldo"] += amount
        loan["status"] = "declined"
        loan["escrowed"] = False
        loan["declined_at"] = agora_ts()
        salvar_dados(dados); salvar_dividas(dividas)
        await query.answer("❌ Você recusou a proposta. O valor foi devolvido ao ofertante.", show_alert=True)
        try: await context.bot.send_message(int(lender_uid), f"❌ Sua proposta #{loan_id} foi RECUSADA. Valor devolvido.")
        except: pass
        try: await query.edit_message_text("❌ Proposta recusada. Valor devolvido ao ofertante.")
        except: pass

async def dividas_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    init_user(uid)
    loans = dividas.get("loans", {})
    numeric_loans = {k: v for k, v in loans.items() if k.isdigit()}
    text_owes = "💸 *DÍVIDAS QUE VOCÊ DEVE:*\n"
    text_receives = "📥 *EMPRÉSTIMOS QUE VOCÊ TEM A RECEBER:*\n"
    has_owe = False; has_receive = False
    for lid in sorted(numeric_loans.keys(), key=lambda x: int(x)):
        loan = numeric_loans[lid]
        if loan["status"] in ("active", "pending"):
            if str(loan["to"]) == uid:
                if loan["status"] == "active":
                    interest = loan["amount"] * (loan["interest_pct"] / 100)
                    total = loan["amount"] + interest
                    due_dt = datetime.datetime.fromtimestamp(loan["due"]).strftime("%d/%m %H:%M")
                    text_owes += f"#{lid} • {formatar(loan['amount'])} + {loan['interest_pct']}% = {formatar(total)} • Vence: {due_dt}\n"
                else:
                    text_owes += f"#{lid} • (PENDENTE) Oferta: {formatar(loan['amount'])}\n"
                has_owe = True
            if str(loan["from"]) == uid:
                if loan["status"] == "active":
                    interest = loan["amount"] * (loan["interest_pct"] / 100)
                    total = loan["amount"] + interest
                    due_dt = datetime.datetime.fromtimestamp(loan["due"]).strftime("%d/%m %H:%M")
                    text_receives += f"#{lid} • {formatar(loan['amount'])} • Devedor: {loan['to']} • Total: {formatar(total)} • Vence: {due_dt}\n"
                else:
                    text_receives += f"#{lid} • (PENDENTE) Proposta para {loan['to']} • Valor: {formatar(loan['amount'])}\n"
                has_receive = True
    if not has_owe: text_owes += "— Nenhuma dívida ativa.\n"
    if not has_receive: text_receives += "— Ninguém te deve (por enquanto).\n"
    await update.message.reply_text(text_owes + "\n" + text_receives, parse_mode="Markdown")

async def pagar_emprestimo_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    payer = str(update.effective_user.id)
    init_user(payer)
    if len(context.args) != 1: return await update.message.reply_text("Uso: /pagar_emprestimo <id>")
    loan_id = context.args[0].lstrip("#")
    loan = dividas.get("loans", {}).get(loan_id)
    if not loan: return await update.message.reply_text("❌ Empréstimo não encontrado.")
    if loan["status"] != "active": return await update.message.reply_text("❌ Esse empréstimo não está ativo.")
    if str(loan["to"]) != payer: return await update.message.reply_text("❌ Você não é o devedor desta dívida.")
    amount = float(loan["amount"])
    interest = amount * (loan["interest_pct"] / 100)
    total = amount + interest
    if dados["users"][payer]["saldo"] < total: return await update.message.reply_text(f"❗ Saldo insuficiente. Total a pagar: {formatar(total)} coins.")
    lender = loan["from"]
    dados["users"][payer]["saldo"] -= total
    if lender == "casino": dados["banco_cassino"] = dados.get("banco_cassino", 0) + total
    else:
        init_user(lender)
        dados["users"][str(lender)]["saldo"] += total
    loan["status"] = "paid"
    loan["paid_at"] = agora_ts()
    salvar_dados(dados); salvar_dividas(dividas)
    await update.message.reply_text(f"✅ Dívida #{loan_id} quitada com sucesso! Você pagou {formatar(total)} coins (incl. juros).")

async def emprestimo_cassino_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    borrower = str(update.effective_user.id)
    init_user(borrower)
    if len(context.args) != 1: return await update.message.reply_text("Uso: /emprestimo_cassino <valor>")
    try: valor = float(context.args[0].replace(",", "."))
    except: return await update.message.reply_text("❗ Valor inválido.")
    if valor <= 0: return await update.message.reply_text("❗ Valor deve ser maior que 0.")
    banco = dados.get("banco_cassino", 0)
    if banco < valor: return await update.message.reply_text("💀 O cofre do Cassino não tem saldo suficiente no momento. Aguarde por mais taxas.")
    dados["banco_cassino"] = banco - valor
    salvar_dados(dados)
    loan_id = gerar_loan_id_sequencial()
    now = agora_ts()
    dividas.setdefault("loans", {})[loan_id] = {
        "id": loan_id, "from": "casino", "to": borrower, "amount": valor, "interest_pct": EMP_CASINO_INTEREST,
        "created": now, "due": now + LOAN_DEFAULT_DAYS * 24 * 3600, "status": "active", "activated": now, "escrowed": False
    }
    dados["users"][borrower]["saldo"] += valor
    salvar_dados(dados); salvar_dividas(dividas)
    await update.message.reply_text(f"🏦 Empréstimo do Cassino concedido! ID: #{loan_id} | Valor: {formatar(valor)} coins | Juros: {EMP_CASINO_INTEREST}% | Prazo: {LOAN_DEFAULT_DAYS} dia(s)")

async def resetconta_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMINS: return await update.message.reply_text("❌ Apenas admins podem usar esse comando.")
    target = None
    if update.message.reply_to_message: target = str(update.message.reply_to_message.from_user.id)
    elif len(context.args) == 1: target = context.args[0]
    else: return await update.message.reply_text("Use: /resetconta <@usuário/id> ou responda a mensagem do usuário.")
    if target in dados["users"]:
        dados["users"].pop(target)
        salvar_dados(dados)
        await update.message.reply_text(f"✅ Conta do usuário {target} resetada com sucesso.")
    else: await update.message.reply_text("❗ Usuário não encontrado.")

async def resetarrank_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMINS: return await update.message.reply_text("❌ Apenas admins.")
    for uid, info in dados.get("users", {}).items():
        info["stats"] = {"vitorias": 0, "derrotas": 0}
    dados["stats"] = {"total_vitorias": 0, "total_derrotas": 0}
    salvar_dados(dados)
    await update.message.reply_text("✅ Ranking/reset de estatísticas reiniciado.")

async def zera_divida_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMINS: return await update.message.reply_text("❌ Apenas admins.")
    if update.message.reply_to_message: target = str(update.message.reply_to_message.from_user.id)
    elif len(context.args) == 1: target = context.args[0]
    else: return await update.message.reply_text("Use: /zera_divida <@usuário/id> (responda a mensagem ou informe o ID).")
    loans = dividas.get("loans", {})
    removed = []
    for lid, loan in list(loans.items()):
        if str(loan.get("to")) == str(target) or str(loan.get("from")) == str(target):
            if loan.get("escrowed") and loan.get("from"):
                init_user(loan["from"])
                dados["users"][str(loan["from"])]["saldo"] += float(loan.get("amount", 0))
            loans.pop(lid, None)
            removed.append(lid)
    dividas["loans"] = loans
    salvar_dividas(dividas); salvar_dados(dados)
    await update.message.reply_text(f"✅ Removidas dívidas: {', '.join(removed) if removed else 'nenhuma'}")

async def taxa_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMINS: return await update.message.reply_text("❌ Apenas admins.")
    await update.message.reply_text(f"🏦 Cofre do Cassino: {formatar(dados.get('banco_cassino',0))} coins")

async def inventario_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    init_user(uid)
    itens = dados["users"][uid].setdefault("itens", {})
    linhas = ["🎒 *Seu inventário da floresta:*\n"]
    tem_item = False
    for key, info in LOJA_ITENS.items():
        qtd = int(itens.get(key, 0))
        if qtd > 0:
            tem_item = True
            linhas.append(f"{info['nome']} — {qtd}x")
    # Mostra itens antigos caso ainda existam no JSON.
    antigos = {"caixa": "🎁 Caixa antiga", "renasorte": "🍀 Trevo antigo", "chapeu": "🍯 Multiplicador antigo", "vip": "👑 VIP antigo"}
    for key, nome in antigos.items():
        qtd = int(itens.get(key, 0))
        if qtd > 0:
            tem_item = True
            linhas.append(f"{nome} — {qtd}x")
    if not tem_item:
        linhas.append("Você ainda não tem itens. Use /loja para comprar.")
    await update.message.reply_text("\n".join(linhas), parse_mode="Markdown")

async def usar_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    init_user(uid)
    if len(context.args) != 1:
        return await update.message.reply_text("Use: /usar <item>")
    item = ITEM_ALIASES.get(context.args[0].lower(), context.args[0].lower())
    itens = dados["users"][uid].setdefault("itens", {})
    efeitos = dados["users"][uid].setdefault("efeitos", {})

    def consumir(chave):
        if itens.get(chave, 0) <= 0:
            return False
        itens[chave] -= 1
        return True

    if item == "semente":
        if not consumir("semente") and not consumir("caixa"):
            return await update.message.reply_text("❌ Você não tem esse item.")
        premio = random.randint(1000, 12000)
        dados["users"][uid]["saldo"] += premio
        msg = f"🌱 A Semente da Sorte brotou! Você ganhou {formatar(premio)} coins."
    elif item == "mel":
        if not consumir("mel") and not consumir("chapeu"):
            return await update.message.reply_text("❌ Você não tem esse item.")
        efeitos["pocao_next"] = True
        msg = "🍯 Mel Dourado ativado! Sua próxima vitória no cassino será dobrada."
    elif item == "vassoura":
        if not consumir("vassoura"):
            return await update.message.reply_text("❌ Você não tem esse item.")
        efeitos["vassoura_end"] = agora_ts() + 24 * 3600
        msg = "🪶 Asa de Beija-flor ativada por 24h: cooldowns reduzidos pela metade."
    elif item == "baudeouro":
        if not consumir("baudeouro"):
            return await update.message.reply_text("❌ Você não tem esse item.")
        premio = random.randint(25000, 150000)
        dados["users"][uid]["saldo"] += premio
        msg = f"🪵 Você abriu o Baú da Clareira e ganhou {formatar(premio)} coins!"
    elif item == "mapa":
        if not consumir("mapa"):
            return await update.message.reply_text("❌ Você não tem esse item.")
        efeitos["mapa_next"] = True
        msg = "🗺️ Mapa da Trilha ativado! Seu próximo /explorar terá recompensa maior."
    elif item in ("trevo", "escudo", "vipfloresta"):
        msg = "ℹ️ Esse item é automático: trevo aumenta a próxima chance, escudo reduz a próxima perda e VIP dobra o bônus."
    else:
        return await update.message.reply_text("❌ Item não encontrado.")

    salvar_dados(dados)
    await update.message.reply_text(msg)

async def trabalhar_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    init_user(uid)
    agora = agora_ts()
    last = dados["users"][uid].get("ultimo_trabalho", 0)
    cooldown = 3600
    if agora - last < cooldown:
        restante = cooldown - (agora - last)
        return await update.message.reply_text(f"⏳ Você já trabalhou. Volte em {restante//60}m.")
    premio = random.randint(500, 2500)
    dados["users"][uid]["saldo"] += premio
    dados["users"][uid]["ultimo_trabalho"] = agora
    salvar_dados(dados)
    await update.message.reply_text(f"🪓 Você cuidou da trilha da floresta e recebeu {formatar(premio)} coins.")

async def explorar_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = str(update.effective_user.id)
    init_user(uid)
    agora = agora_ts()
    last = dados["users"][uid].get("ultimo_explorar", 0)
    cooldown = 2 * 3600
    if agora - last < cooldown:
        restante = cooldown - (agora - last)
        return await update.message.reply_text(f"⏳ A trilha ainda está fechada. Volte em {restante//60}m.")
    efeitos = dados["users"][uid].setdefault("efeitos", {})
    base_min, base_max = (2000, 8000) if efeitos.pop("mapa_next", False) else (500, 4000)
    premio = random.randint(base_min, base_max)
    achou_item = random.random() < 0.12
    texto = f"🧭 Você explorou a floresta e encontrou {formatar(premio)} coins."
    dados["users"][uid]["saldo"] += premio
    if achou_item:
        item = random.choice(["semente", "trevo", "escudo"])
        dados["users"][uid].setdefault("itens", {})[item] = dados["users"][uid]["itens"].get(item, 0) + 1
        texto += f"\n🎒 Bônus: encontrou {LOJA_ITENS[item]['nome']}!"
    dados["users"][uid]["ultimo_explorar"] = agora
    salvar_dados(dados)
    await update.message.reply_text(texto)

async def ajuda_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    texto = (
        "🌿 Ajuda — Cassino Bombardeiro / Floresta Bombardeira\n\n"
        "Comandos principais:\n"
        "/start - Entrar no Cassino\n"
        "/saldo - Ver seu saldo\n"
        "/bonus - Pegar bônus diário\n"
        "/cassino <valor|all> - Jogar na roleta\n"
        "/loja - Ver a loja\n"
        "/comprar <item> - Comprar item da loja\n"
        "/usar <item> - Usar item do inventário\n"
        "/inventario - Ver seus itens\n"
        "/trabalhar - Ganhar coins uma vez por hora\n"
        "/explorar - Explorar a floresta e achar recompensas\n"
        "/rank - Ver ranking\n"
        "/doar <valor> (responder) - Doar coins\n\n"
        "Empréstimos:\n"
        "/emprestar <valor> <juros%?> <dias?> - (RESPONDENDO) Oferecer empréstimo\n"
        "/dividas - Ver dívidas\n"
        "/pagar_emprestimo <id> - Quitar dívida\n"
        "/emprestimo_cassino <valor> - Pegar empréstimo do Cassino\n"
    )
    await update.message.reply_text(texto)
    
# ---------------- scheduled drops (hora em hora) ----------------
async def scheduled_drop_task(app):
    print("Iniciando tarefa de drops agendados...")
    while True:
        agora = datetime.datetime.now()
        current_hour = agora.hour

        if agora.minute == 0 and current_hour != hourly_drop_status.get("last_hour"):
            valor = random.randint(100, 5000)
            quantidade = 1
            titulo_drop = random.choice([
                "🌿 Drop da Floresta",
                "🍃 Folhas Premidas",
                "🦋 Presente da Clareira",
                "🌳 Tesouro Natural",
            ])

            drop_id = str(uuid.uuid4())
            drops[drop_id] = {"valor": valor, "quantidade": quantidade, "pegos": []}
            salvar_drops(drops)
            kb = [[InlineKeyboardButton("🎁 Resgatar", callback_data=f"pegardrop_{drop_id}")]]

            try:
                await app.bot.send_message(
                    chat_id=CHAT_ID,
                    text=(
                        f"{titulo_drop} — Cassino Bombardeiro!\n"
                        f"💰 Valor: {formatar(valor)} coins\n"
                        "🎁 Corre pegar antes que acabe!"
                    ),
                    reply_markup=InlineKeyboardMarkup(kb)
                )
                hourly_drop_status["last_hour"] = current_hour
                print("[DropTask] Drop normal enviado.")
            except Exception as e:
                print("[DropTask] Erro ao enviar drop:", e)

        await asyncio.sleep(60)

# ---------------- inicialização e handlers ----------------
if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()

    handlers = [
        ("start", iniciar), ("iniciar", iniciar), ("saldo", saldo_cmd), ("coins", saldo_cmd), 
        ("bonus", bonus_cmd), ("cassino", cassino_cmd), ("loja", loja_cmd), ("comprar", comprar_cmd), ("usar", usar_cmd), ("inventario", inventario_cmd),
        ("trabalhar", trabalhar_cmd), ("explorar", explorar_cmd),
        ("rank", rank_cmd), ("doar", doar_cmd), ("addsaldo", addsaldo_cmd), ("drop", drop_cmd),
        ("cassino_saldo", cassino_saldo_cmd), ("coletartaxa", coletartaxa_cmd), 
        ("emprestar", emprestar_cmd), ("dividas", dividas_cmd), ("pagar_emprestimo", pagar_emprestimo_cmd), 
        ("emprestimo_cassino", emprestimo_cassino_cmd), ("ajuda", ajuda_cmd), 
        ("resetconta", resetconta_cmd), ("resetarrank", resetarrank_cmd), ("zera_divida", zera_divida_cmd), 
        ("cassino_status", cassino_status_cmd), ("taxa", taxa_cmd),
    ]

    for nome, func in handlers:
        app.add_handler(CommandHandler(nome, func))

    # CALLBACK HANDLERS (AGORA COM A FUNÇÃO DEFINIDA)
    app.add_handler(CallbackQueryHandler(loan_response_callback, pattern=r"^loanresp\|"))
    app.add_handler(CallbackQueryHandler(pegar_drop_callback, pattern=r"^pegardrop_")) 

    print("🌿 Cassino Bombardeiro iniciado! Rodando o bot...")

    # iniciar tarefa de drops por hora
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.create_task(scheduled_drop_task(app))

    app.run_polling()