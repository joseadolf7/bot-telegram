COMO SUBIR NO RAILWAY SEM GITHUB

1) Extraia este ZIP no celular ou computador.
2) Instale o Railway CLI ou use um terminal/cloud shell com Railway CLI.
3) Dentro da pasta extraida, rode:
   railway login
   railway init
   railway variables set TOKEN=SEU_TOKEN_DO_BOTFATHER
   railway up

Comando de start ja configurado: python main.py

IMPORTANTE:
- O token nao esta mais fixo dentro do main.py.
- Voce precisa criar a variavel TOKEN no Railway.
- Nao publique dados.json, drops.json e dividas.json em repositorio publico se eles tiverem dados reais.
